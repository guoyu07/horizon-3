tinyMCE.addI18n('zh_cn.paste_dlg',{
text_title:"\u5C06\u590D\u5236(CTRL + C)\u7684\u5185\u5BB9\u7C98\u8D34(CTRL + V)\u5230\u7A97\u53E3\u3002",
text_linebreaks:"\u4FDD\u7559\u5206\u884C\u7B26\u53F7\u53F7",
word_title:"\u5C06\u590D\u5236(CTRL + C)\u7684\u5185\u5BB9\u7C98\u8D34(CTRL + V)\u5230\u7A97\u53E3\u3002"
});