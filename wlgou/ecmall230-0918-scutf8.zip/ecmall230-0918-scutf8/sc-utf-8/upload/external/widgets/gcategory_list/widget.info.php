<?php

return array(
    'name'      => 'gcategory_list',
    'display_name'  => '商品分类',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示展示第一第二级商品分类，适合放在比较宽的区域。',
    'configurable'  => true,
);

?>