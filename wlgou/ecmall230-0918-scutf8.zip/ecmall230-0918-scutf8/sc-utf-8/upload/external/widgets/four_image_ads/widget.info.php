<?php

return array(
    'name'      => 'four_image_ads',
    'display_name'  => '4个图片广告',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '横排展示4个图片广告，广告图片尺寸为188*98',
    'configurable'  => true,
);

?>