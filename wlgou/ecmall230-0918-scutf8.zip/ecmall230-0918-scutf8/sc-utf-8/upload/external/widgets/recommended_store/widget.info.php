<?php

return array(
    'name'      => 'recommended_store',
    'display_name'  => '推荐店铺',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示推荐店铺的挂件，可以设置数量，适合放在比较窄的区域。',
    'configurable'  => true,
);

?>