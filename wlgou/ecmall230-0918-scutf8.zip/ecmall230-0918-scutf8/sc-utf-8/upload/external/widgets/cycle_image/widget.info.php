<?php

return array(
    'name'      => 'cycle_image',
    'display_name'  => '轮播图片',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '循环展示最多6个图片广告，图片广告在后台设置',
    'configurable'  => true,
);

?>