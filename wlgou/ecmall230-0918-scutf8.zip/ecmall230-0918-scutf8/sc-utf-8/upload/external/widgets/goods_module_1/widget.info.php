<?php

return array(
    'name'      => 'goods_module_1',
    'display_name'  => '商品模块1',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示一个广告和一组商品，广告图片尺寸为210*280，商品有4个以图文展示，有8个以文字展示，适合放在首页。',
    'configurable'  => true,
);

?>