<?php

return array(
    'name'      => 'recommended_groupbuy',
    'display_name'  => '推荐团购活动',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '显示6个由后台推荐的团购活动',
    'configurable'  => false,
);

?>