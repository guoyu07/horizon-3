<?php

/**
 * 注册和加盟按钮挂件
 */
class Register_and_applyWidget extends BaseWidget
{
    var $_name = 'register_and_apply';
}

?>