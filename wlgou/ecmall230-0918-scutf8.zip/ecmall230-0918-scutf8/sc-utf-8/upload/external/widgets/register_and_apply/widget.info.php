<?php

return array(
    'name'      => 'register_and_apply',
    'display_name'  => '注册和加盟按钮',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示注册和加盟按钮',
);

?>