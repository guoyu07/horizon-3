<?php

return array(
    'name'      => 'advt',
    'display_name'  => '广告',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '显示一个广告（包括图片广告、文字广告、代码广告和flash广告）',
    'configurable'  => true,
);

?>