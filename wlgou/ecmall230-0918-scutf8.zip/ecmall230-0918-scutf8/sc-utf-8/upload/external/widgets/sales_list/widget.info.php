<?php

return array(
    'name'      => 'sales_list',
    'display_name'  => '销售排行',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示销量排行前十的商品，适合放在比较窄的区域。',
);

?>