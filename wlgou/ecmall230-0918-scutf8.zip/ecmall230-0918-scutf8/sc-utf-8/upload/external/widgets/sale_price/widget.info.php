<?php

return array(
    'name'      => 'sale_price',
    'display_name'  => '特价商品',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '能展示3个有图片和文字的商品和4个只有文字的商品，商品数据从推荐类型中取',
    'configurable'  => true,
);

?>