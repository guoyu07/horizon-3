<?php

return array(
    'name'      => 'latest_sold',
    'display_name'  => '最新成交',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示最新成交的商品，可以设置数量，适合放在比较窄的区域。',
    'configurable'  => true,
);

?>