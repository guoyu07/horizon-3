<?php

return array(
    'name'      => 'brand',
    'display_name'  => '品牌区',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示推荐品牌，可以设置显示数量，适合放在比较窄的区域。',
);

?>