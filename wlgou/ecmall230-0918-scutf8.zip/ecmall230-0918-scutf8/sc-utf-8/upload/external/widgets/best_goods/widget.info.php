<?php

return array(
    'name'      => 'best_goods',
    'display_name'  => '精品推荐',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '能展示6个有图片和文字的商品，商品数据从推荐类型中取',
    'configurable'  => true,
);

?>