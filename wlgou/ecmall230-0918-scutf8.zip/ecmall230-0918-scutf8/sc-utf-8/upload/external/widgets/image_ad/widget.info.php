<?php

return array(
    'name'      => 'image_ad',
    'display_name'  => '图片广告',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '显示一个图片广告',
    'configurable'  => true,
);

?>