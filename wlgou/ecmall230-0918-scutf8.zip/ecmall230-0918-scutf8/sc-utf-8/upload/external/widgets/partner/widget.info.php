<?php

return array(
    'name'      => 'partner',
    'display_name'  => '合作伙伴',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '展示合作伙伴，可以设置显示数量，适合放在页面底部。',
    'configurable'  => true,
);

?>