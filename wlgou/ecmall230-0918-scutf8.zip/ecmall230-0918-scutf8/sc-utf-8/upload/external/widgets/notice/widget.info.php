<?php

return array(
    'name'      => 'notice',
    'display_name'  => '公告栏',
    'author'    => 'ECMall Team',
    'website'   => 'http://ecmall.shopex.cn',
    'version'   => '1.0',
    'desc'      => '显示最新公告及1个图片广告，广告图片尺寸为180*60',
    'configurable'  => true,
);

?>