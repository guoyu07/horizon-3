<?php

return array(
    'id' => 'short_store_url',
    'hook' => 'on_run_action',
    'name' => '店铺地址简写插件',
    'desc' => '本插件可以简化店铺访问地址为“http://商城网址/?店铺id”。',
    'author' => 'ECMall Team',
    'version' => '1.0',
);

?>