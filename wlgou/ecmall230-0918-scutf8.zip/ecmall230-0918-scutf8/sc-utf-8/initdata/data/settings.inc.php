<?php 
return array (
  'site_name' => 'ECMall演示站',
  'site_title' => 'ECMall演示站',
  'site_description' => '这是一个使用 ecmall 搭建的网上商城。',
  'site_keywords' => 'ecmall 商城 小淘宝',
  'icp_number' => '',
  'site_status' => '1',
  'closed_reason' => '',
  'hot_search' => '外套,女装,女鞋,女裙,女裤',
);
?>