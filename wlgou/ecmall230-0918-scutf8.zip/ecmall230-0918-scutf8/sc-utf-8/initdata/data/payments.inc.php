<?php

return array (
  0 => 'alipay',
  1 => 'tenpay2',
  2 => 'tenpay',
  3 => 'post',
  4 => 'paypal',
  5 => 'bank',
  6 => 'cod',
);

?>