<?php

return array(
    'config' => '系统配置',
    'ecmall_integrate_guide' => 'ECMall 整合向导',
    'next_step' => '下一步',
    'welcome_integrate_ecmall' => '您好，欢迎使用 ECMall 整合程序',
    'select_systems' => '请选择您需要整合的系统',
    'available_systems' => '可选系统'
);

?>
